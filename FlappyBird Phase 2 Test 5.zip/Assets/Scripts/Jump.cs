using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Jump : MonoBehaviour
{
    [SerializeField] private Animator animator;
    [SerializeField] private Rigidbody2D player;
    [SerializeField] private float thrust = 5f;

    private void Update()
    {
        //if(Input.touchCount>0)
        if(Input.GetKeyDown(KeyCode.W))
        {
            animator.SetTrigger("Fly");    
            player.velocity = new Vector2(0, thrust);
        }
    }
}
