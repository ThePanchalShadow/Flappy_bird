using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public class SpawnPipes : MonoBehaviour
{
    [SerializeField] GameObject prefab;
    [SerializeField] float SpawnX;
    [SerializeField] float repeatTime= 4f;


    // Start is called before the first frame update

    void spawnPipes()
    {
        Vector2 spawnPos = new Vector2(SpawnX,Random.Range(-4.4f,-1.5f));
        Instantiate(prefab,spawnPos,Quaternion.identity);
    }
    // Update is called once per frame
    void Start()
    {
        InvokeRepeating("spawnPipes", 0f ,repeatTime);
    }


}
