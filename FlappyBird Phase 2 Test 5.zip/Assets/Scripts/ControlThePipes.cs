using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

public class ControlThePipes : MonoBehaviour
{
    [SerializeField] private float speed = 0.5f;
    private float OutOfBound = -10;
    // Update is called once per frame
    void LateUpdate()
    {
        transform.Translate(Vector3.left * speed * Time.deltaTime);
        if (transform.position.x < OutOfBound)
        {
            Destroy(gameObject);
        }
    }

}
